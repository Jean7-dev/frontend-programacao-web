import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../ambientes/environment';

@Component({
  selector: 'app-cliente',
  template: `
    <h2>Cadastro de Clientes</h2>
    <form (ngSubmit)="salvarCliente()">
      <input [(ngModel)]="cliente.nome" name="nome" placeholder="Nome" required>
      <input [(ngModel)]="cliente.sobrenome" name="sobrenome" placeholder="Sobrenome">
      <input [(ngModel)]="cliente.email" name="email" placeholder="Email" required>
      <input [(ngModel)]="cliente.telefone" name="telefone" placeholder="Telefone">
      <button type="submit">Salvar</button>
    </form>

    <hr>

    <div *ngFor="let c of clientes">
      <strong>{{c.nome}} {{c.sobrenome}}</strong> - {{c.email}} ({{c.telefone}})
      <button (click)="excluirCliente(c.id)">Excluir</button>
    </div>
  `
})
export class ClienteComponent implements OnInit {
  clientes: any[] = [];
  cliente: any = {};

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.carregarClientes();
  }

  carregarClientes() {
    this.http.get<any[]>(environment.apiUrl).subscribe(data => this.clientes = data);
  }

  salvarCliente() {
    this.http.post(environment.apiUrl, this.cliente).subscribe(() => {
      this.cliente = {};
      this.carregarClientes();
    });
  }

  excluirCliente(id: number) {
    this.http.delete(environment.apiUrl + '/' + id).subscribe(() => this.carregarClientes());
  }
}