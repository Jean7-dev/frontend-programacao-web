# E-commerce Frontend

Frontend Angular integrado ao backend (clientes).

## 🚀 Como usar

1. Instale as dependências:
```
npm install
```

2. Execute o servidor de desenvolvimento:
```
ng serve
```

3. Acesse no navegador:
```
http://localhost:4200
```

## 🌐 API Backend
O frontend se conecta ao backend em `http://localhost:3000/api/clientes`.
